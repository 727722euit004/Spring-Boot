package com.example.q3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q3Application {

	public static void main(String[] args) {
		SpringApplication.run(Q3Application.class, args);
	}

}
